enum StateStatus {
  initial,
  running,
  loading,
  succes,
  error,
}
