class Failure {
  String message;
  Failure(this.message);
}
