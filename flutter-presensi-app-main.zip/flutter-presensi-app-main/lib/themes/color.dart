import 'package:flutter/material.dart';

Color lightYellowColor = const Color(0xffFFD600);
Color darkYellowColor = const Color(0xffCEBA00);
Color lightBlueColor = const Color(0xff5C9CFC);
Color darkBlueColor = const Color(0xff1462FA);
Color greenColor = const Color(0xff4EB000);
Color redColor = const Color(0xffEE4242);
Color greyColor = const Color(0xffAAAAAA);
