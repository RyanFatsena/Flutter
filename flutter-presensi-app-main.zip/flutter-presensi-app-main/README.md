# Presensi App

Aplikasi ini untuk memenuhi project UAS SIG

## Link Demo
[Click Here](https://www.youtube.com/watch?v=GUZd5MYsqiw)

## How to Start
1. Buatlah akun firebase anda, dan tambahkan google-service.jsonnya di android/app/
2. Kemudian tambahkan API Key Google Maps anda di android/app/src/main/AndroidManifest.xml

## Download Aplikasi
[Click Here](https://github.com/achyusuf10/flutter-presensi-app/raw/main/app-release.apk)

## Structure Firebase
<img src="https://user-images.githubusercontent.com/65402864/180636480-dd2f1ef9-34fc-41a0-acee-61652f48da19.png" width=800>
<img src="https://user-images.githubusercontent.com/65402864/180636484-1fb56a1c-f58b-462a-9ca3-820a5cff597e.png" width=800>

## For Testing
• email : test@gmail.com
• pwd : 123123

## To Do
- Buat Versi Adminnya
- Klo Sudah Absen kasih notif, sudah absen dan absen nya nggk masuk ke DB
- Buat Register Page
